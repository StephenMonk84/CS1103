package com.ecommerce;
import java.util.ArrayList;

import com.ecommerce.Product;

public class Customer {
    private String custName, custID;
    private ArrayList<Product> shopCart = new ArrayList<Product>();

    public void testPrint(){
        System.out.println("This means the second file in the package works.");
    }

    public void addToCart(Product addProd){
        shopCart.add(addProd);
        
    }
    
}

