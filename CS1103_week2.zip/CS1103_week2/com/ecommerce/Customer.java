package com.ecommerce;
import java.util.ArrayList;
import com.ecommerce.Product;

public class Customer {
    private String custName, custID;
    private ArrayList<Product> shopCart = new ArrayList<Product>(); 
    private int amountInCart;

    public Customer(String custID, String custName){
        this.custName = custName;
        this.custID = custID;
    }

    public void testPrint(){
        System.out.println("This means the second file in the package works.");
    }

    public void addToCart(Product addProd){
        shopCart.add(addProd);
        System.out.println(shopCart.size());
        shopCart.get(0).lowerInv(1);
    }
    public String getCustID(){
        return custID;
    }
    public String getCustName(){
        return custName;
    }
    public int getAmountInCart(){
        return amountInCart;
    }
    public ArrayList<Product> getCartItems(){
        System.out.println(shopCart.size());
        return shopCart;
    }
    public void setCustID(String newID){
        this.custID = newID;
    }

    public void setCustName(String newName){
        this.custName = newName;
    }

    public double totalCart(){
        double total=0;
        for(int i=0; i<shopCart.size();i++){
            total = total + shopCart.get(i).getPrice();
        }
        return total;
    }

    public void removeFromCart(Product remProd){
        shopCart.get(shopCart.size()-1).addInv(getAmountInCart());
        shopCart.remove(remProd);
        
    }

    public void shopCartoUT(){
        System.out.println("The customer " + getCustName() + " has " + shopCart.get(0).printInv());
        System.out.println("The inventory is " + shopCart.get(0).getInventory());
    }
    
}

