package com.ecommerce.orders;

import com.ecommerce.*;

public class Order {
    private String orderID;
    private Customer cust[];
    private double totalAmount;

    public Order(){
        cust= new Customer();
    }

    public double getTotalAmount(){
        System.out.println(cust[0].getTotalAmount());
        return cust[0].getTotalAmount();
    }
}
