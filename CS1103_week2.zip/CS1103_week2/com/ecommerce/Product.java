package com.ecommerce;

public class Product{
    private String productID, productName;
    private double price;
    private int inventory;
    //Need to setup other relevant attributes
    public Product(String prodID, String prodName, double price, int inv){
        this.productID = prodID;
        this.productName = prodName;
        this.price = price;
        this.inventory = inv;
    }

    public Product(){
    }
    
    public String getProductID(){
        return productID;
    }

    public String getProductName(){
        return productName;
    }

    public double getPrice(){
        return price;
    }
    public int getInventory(){
        return inventory;
    }
    public void setProductID(String prodID){
        this.productID = prodID;
    }

    public void setProductName(String productName){
        this.productName = productName;
    }

    public void setPrice(double newPrice){
        this.price = newPrice;
    }
    public void setInventory(int invLevel){
        this.inventory = invLevel;
    }
    public void lowerInv(int shoppingCart){
        this.inventory = this.inventory - shoppingCart;
    }
    public void addInv(int shoppingCart){
        this.inventory = this.inventory + shoppingCart;
    }
}


