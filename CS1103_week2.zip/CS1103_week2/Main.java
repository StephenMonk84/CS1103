import com.ecommerce.*;
public class Main {
    public static void main(String[] args){
        Product obj = new Product("1234", "Test Name", 5.00, 10);
        System.out.println("The product is " + obj.getProductID()+ " the name is " + obj.getProductName() + " the price is " + obj.getPrice()+ ".");
        Customer obj1 = new Customer();
        obj1.testPrint();
    }
    
}
