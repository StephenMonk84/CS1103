import com.ecommerce.Product;
import com.ecommerce.Customer;
import com.ecommerce.orders.Order;
public class Main {
    public static void main(String[] args){
        Product obj = new Product("1234", "Test Name", 5.00, 10);
        Product objTest1 = new Product("2345", "Another Name", 7.35, 8);
        Product objTest2 = new Product("3456", "A third test object", 8.97, 7);
        System.out.println("The product is " + obj.getProductID()+ " the name is " + obj.getProductName() + " the price is " + obj.getPrice()+ ".");
        Customer obj1 = new Customer("1234", "Bob");
        Order obj2 = new Order();
        obj1.testPrint();
        obj1.addToCart(obj);
        obj1.addToCart(objTest2);
        obj1.addToCart(objTest1);
        obj1.shopCartoUT();
        obj2.generateSummary();
        obj2.getTotalAmount();
    }
    
}
